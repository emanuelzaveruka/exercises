# Banco de dados com erro

- professora meu banco de dados deu o mesmo erro do video, mesmo tentanto corrigir como ele fez, não funcionou.
- estou enviando o script do banco de dados para você dar uma olhada
- o codigo php também será enviado. 